# LiberateToAutomate
Project 1 Starting Point for CS-256
